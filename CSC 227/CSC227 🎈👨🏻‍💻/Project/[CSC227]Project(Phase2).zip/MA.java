import java.util.*;
import java.io.*;
 
public class MA {

   static  MI obj= new MI();

   public static void main(String[] args) {
   
      Scanner input = new Scanner(System.in);
   
      String Pname;
      int sizeP_KB;
      char allocation_strategy;
   
      int choice;
      do {
          // PROMPT THE USER
         System.out.println("Please Enter Number of your Choice:  ");
         System.out.println("[1 for  (request), 2 for (release), 3 for (status report), or 4 for (exit)]");
         choice = input.nextInt();
          // START RUNNING DIFFERENT CHOICES
         switch (choice) {
         
            case 1:
               System.out.println("Enter the allocation request�s information, i.e.: ");
               System.out.println("Enter The process name :  ");
               Pname = input.next();
               System.out.println("Enter The size of the process in KB:");
               sizeP_KB = input.nextInt();
               System.out.println(
                   "Enter a Character for The allocation strategy (W: worst fit) - (F : first fit) - (B : Best fit) ");
               allocation_strategy = input.next().charAt(0);
            
               switch (allocation_strategy) {
               
                  case 'W':
                  case 'w':
                     worstFit(Pname, sizeP_KB);
                     break;
                  case 'B':
                  case 'b':
                     BestFit(Pname, sizeP_KB);
                     break;
                  case 'F':
                  case 'f':
                     firstFit(Pname, sizeP_KB);
                     break;
                  default:
                     System.out.println("Please enter a sutible character. Only F or B or W. ");
                     break;
               }
               break;
               
            case 2:
               System.out.println("Enter the process name to be released from the memory:");
               Pname = input.next();
               if (release(Pname))
                  System.out.println("Released Successfully. ");
               break;
         
            case 3:
               obj.printReport();
               break;
         
            case 4:
               System.out.println("Exit.");
               break;
         
            default:
               System.out.println("Please Enter only 1 or 2 or 3 or 4.");
               break;
         }
      } while (choice != 4);
   } // end main
   

   static void firstFit(String Pname, int sizeP_KB) {
                  //check for free partition
      boolean flag=true;
      for(int i=0; i<obj.PartitionStatus.length; i++ ){
         if(obj.PartitionStatus[i].equals("Free")&&obj.arr[i]>=sizeP_KB){
            flag=false;
            obj.ProcessName[i]=Pname;
            obj.PartitionStatus[i]= "Allocated";
            obj.internalFragmentation[i]= (obj.arr[i]-sizeP_KB);
            break;
         }
      }
      if(flag)
         System.out.println("insufficient allocation request.\n");
   }

 
   static void worstFit(String Pname, int sizeP_KB) {
      
      boolean flag=true;
      String array[]=obj.PartitionStatus;
      int max=0 ,i=0, j=0;
      for(i=0; i< array.length; i++)
         if(array[i].equals("Free")){
            if(obj.arr[i]>=obj.arr[j] && sizeP_KB<=obj.arr[i]){
               max=i;
               flag=false;
            }
         }
         else
            j++;
      if(flag)
         System.out.println("insufficient allocation request.");
      else{
         obj.ProcessName[max]=Pname;
         obj.PartitionStatus[max]= "Allocated";
         obj.internalFragmentation[max]= (obj.arr[max]-sizeP_KB);
      }
   }
  

   static void BestFit(String Pname, int sizeP_KB){
      boolean flag=true;
      String array[]=obj.PartitionStatus;
      int min=0, i=0;
      for(i=0; i< array.length; i++)
         if(array[i].equals("Free")){
            if(obj.arr[i]<=obj.arr[min] && sizeP_KB<=obj.arr[i]){
               min=i;
               flag=false;
            }}
         else{
            min++;
         }
      if(flag)
         System.out.println("insufficient allocation request.");
      else{
         obj.ProcessName[min]=Pname;
         obj.PartitionStatus[min]= "Allocated";
         obj.internalFragmentation[min]= (obj.arr[min]-sizeP_KB);
      } 
   }  

   static boolean release(String Pname) {
   
        //searching for process:
      int found=-1;
      for(int i=0; i<obj.ProcessName.length; i++){
         if(obj.ProcessName[i].equals(Pname))
            found=i;
      }
      if(found<0){
         System.out.println("No such name !");
         return false;
      }
          //deleting:
      obj.ProcessName[found]="NULL";
      obj.PartitionStatus[found]="Free";
      obj.internalFragmentation[found]=-1;
      return true;
   }
}