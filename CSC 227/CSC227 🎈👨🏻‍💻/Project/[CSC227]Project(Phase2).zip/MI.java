import java.io.*;
import java.util.*;

public class MI {

   static   Scanner input = new Scanner(System.in);

   static String[] PartitionStatus ;
   static int[] internalFragmentation ;
   static int[] st_address ;
   static int[] end_address ;
   static String[] ProcessName;
   static  int[] arr;
   
   MI(){
   
      System.out.println("Please Enter the number of partitions (M): ");
      int numOfM = input.nextInt();
      arr = new int[numOfM];
      PartitionStatus = new String[numOfM];
      internalFragmentation = new int[numOfM];
      st_address = new int[numOfM];
      end_address = new int[numOfM];
      ProcessName = new String[numOfM];  
      main(numOfM);
   }
   
   
   public static void main(int numOfM) {
   
      int size  ;
      for (int i = 0; i < numOfM; i++) {
      
        // Partition status: Allocated or Free. 
         /*Phase 1, status will be free. */
         PartitionStatus[i] = "Free";         
         System.out.printf("Please Enter the size of partition #%d in KB: %n " , i + 1);
         size = input.nextInt(); // Size of a partition in KB.
         arr[i] = size; 
      //  Starting address of a partition in Bytes(1 KB = 1024 Bytes)
         //  i == 0 first element address is 0 
         if (i == 0) {
            st_address[i] = 0 ; 
         }
         else { 
            st_address[i] = end_address[i-1] + 1;
             
         // Ending address of a partition in Bytes. 
         } 
         end_address[i] = st_address[i] + size * 1024 -1 ;
          
         // The name of the process if Status = Allocated, or Null otherwise.
      
         if (!PartitionStatus[i].equals("Allocated"))
            ProcessName[i] = "NUll";
          // The size of the internal fragmentation in KB if the status is �Allocated�,or -1
         internalFragmentation[i] = -1;
      } // end for loop 
   }

    
   public void printReport() {
       
    /* Printing Report */ 
      System.out.println("-------------------------------------------------------------- ");
      for (int i = 0; i < arr.length; i++) {
         System.out.printf(" The address space of partition #%d is: %n" , i+1 );
         System.out.printf(" Starting address in Bytes: %d %n Ending address in Bytes: %d %n", st_address[i] , end_address[i] ) ;
         System.out.printf(" Partition #%d  status: %s %n" , i+1 , PartitionStatus[i]);
         System.out.printf(" Partition #%d size: %d KB %n" , i+1 , arr[i]);
         System.out.printf(" The current allocated process to partition #%d is : %s %n" , i+1 , ProcessName[i]);
         System.out.printf(" Internal fragmentation size for partition #%d  is: %d KB %n" , i+1 , internalFragmentation[i]);
         System.out.println("-------------------------------------------------------------- ");
      }
         
      File fname = new File ("Report.txt");
      try {
         FileOutputStream fout = new FileOutputStream(fname);
         PrintWriter pr = new PrintWriter(fout);
         pr.println("-------------------------------------------------------------- ");
         for (int i = 0; i < arr.length; i++) {
            pr.printf(" The address space of partition #%d is: %n" , i+1 );
            pr.printf(" Starting address in Bytes: %d %n Ending address in Bytes: %d %n", st_address[i] , end_address[i] ) ;
            pr.printf(" Partition #%d  status: %s %n" , i+1 , PartitionStatus[i]);
            pr.printf(" Partition #%d size: %d KB %n" , i+1 , arr[i]);
            pr.printf(" The current allocated process to partition #%d is : %s %n" , i+1 , ProcessName[i]);
            pr.printf(" Internal fragmentation size for partition #%d  is: %d KB %n" , i+1 , internalFragmentation[i]);
            pr.println("-------------------------------------------------------------- ");
         }
         pr.close();
         fout.close();
      } catch (FileNotFoundException e) {
         e.printStackTrace();
      } catch (IOException e) {
         e.printStackTrace();
      }
   } 
} // end class