import java.util.*;

public class Phase1MI{

   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
   
      System.out.println("Please Enter the number of partitions (M): ");
      int numOfM = input.nextInt();
      int[] arr = new int[numOfM];
   
      String[] PartitionStatus = new String[numOfM];
      int[] internalFragmentation = new int[numOfM];
      int[] st_address = new int[numOfM];
      int[] end_address = new int[numOfM];
      String[] ProcessName = new String[numOfM];
      int size  ;
      for (int i = 0; i < numOfM; i++) {
      
         // Partition status: Allocated or Free. 
         /*Phase 1, status will be free. */
         PartitionStatus[i] = "Free";         
         System.out.printf("Please Enter the size of partition #%d in KB: %n " , i + 1);
         size = input.nextInt(); // Size of a partition in KB.
         
         /*  Note : we stored size in varible " size " and in array "arr"
         in case we need varible size in further use (for exapmle,in phase 2)
          and we do not want to change contents of the array.
         */ 
         
         arr[i] = size; 
      	// Starting address of a partition in Bytes(1 KB = 1024 Bytes)
         // i == 0 first element address is 0 
         if (i == 0) {
            st_address[i] = 0 ; 
         }
         else 
         { st_address[i] = end_address[i-1] + 1;
            /* Ending address of a partition in Bytes. */
         }
         end_address[i] = st_address[i] + size  * 1024 -1  ;
      	// The name of the process if Status = Allocated, or Null otherwise.
         /* Note :  Initially, here conditional if will always evaluate to "true"; 
          Because here in phase 1 we still did not allocate a memory. 
          Therefore, in phase 2 this segment of code may change.   */
         
         if (!PartitionStatus[i].equals("Allocated"))
            ProcessName[i] = "NUll";
          // The size of the internal fragmentation in KB if the status is �Allocated�,or -1
          /*For previous reason in line 43 , this line(51) may also change too. */ 
         internalFragmentation[i] = -1;
      
      } // end for loop 
      
      /* Printing Report */ 
      System.out.println("-------------------------------------------------------------- ");
      for (int i = 0; i < arr.length; i++) {
         System.out.printf(" The address space of partition #%d is: %n" , i+1 );
         System.out.printf(" Starting address in Bytes: %d %n Ending address in Bytes: %d %n", st_address[i] , end_address[i] ) ;
         System.out.printf(" Partition #%d  status: %s %n" , i+1 , PartitionStatus[i]);
         System.out.printf(" Partition #%d size: %d KB %n" , i+1 , arr[i]);
         System.out.printf(" The current allocated process to partition #%d is : %s %n" , i+1 , ProcessName[i]);
         System.out.printf(" Internal fragmentation size for partition #%d  is: %d KB %n" , i+1 , internalFragmentation[i]);
         System.out.println("-------------------------------------------------------------- ");
      }
   
   }

}
